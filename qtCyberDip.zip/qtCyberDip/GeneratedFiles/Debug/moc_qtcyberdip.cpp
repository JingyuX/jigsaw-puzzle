/****************************************************************************
** Meta object code from reading C++ file 'qtcyberdip.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "stdafx.h"
#include "../../qtcyberdip.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qtcyberdip.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_qtCyberDip_t {
    QByteArrayData data[49];
    char stringdata0[721];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_qtCyberDip_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_qtCyberDip_t qt_meta_stringdata_qtCyberDip = {
    {
QT_MOC_LITERAL(0, 0, 10), // "qtCyberDip"
QT_MOC_LITERAL(1, 11, 21), // "bbqDiscoveryReadyRead"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 15), // "bbqClickConnect"
QT_MOC_LITERAL(4, 50, 15), // "bbqSelectDevice"
QT_MOC_LITERAL(5, 66, 16), // "QListWidgetItem*"
QT_MOC_LITERAL(6, 83, 4), // "item"
QT_MOC_LITERAL(7, 88, 20), // "bbqDoubleClickDevice"
QT_MOC_LITERAL(8, 109, 20), // "bbqClickBootstrapUSB"
QT_MOC_LITERAL(9, 130, 18), // "bbqClickConnectUSB"
QT_MOC_LITERAL(10, 149, 21), // "bbqADBProcessFinishes"
QT_MOC_LITERAL(11, 171, 22), // "bbqADBProcessReadyRead"
QT_MOC_LITERAL(12, 194, 20), // "bbqADBErrorReadyRead"
QT_MOC_LITERAL(13, 215, 17), // "bbqQualityChanged"
QT_MOC_LITERAL(14, 233, 5), // "index"
QT_MOC_LITERAL(15, 239, 17), // "bbqBitrateChanged"
QT_MOC_LITERAL(16, 257, 5), // "value"
QT_MOC_LITERAL(17, 263, 20), // "bbqClickShowDebugLog"
QT_MOC_LITERAL(18, 284, 21), // "comClickConnectButton"
QT_MOC_LITERAL(19, 306, 18), // "comClickSendButton"
QT_MOC_LITERAL(20, 325, 19), // "comClickClearButton"
QT_MOC_LITERAL(21, 345, 17), // "comClickHitButton"
QT_MOC_LITERAL(22, 363, 17), // "comClickRetButton"
QT_MOC_LITERAL(23, 381, 13), // "comMoveStepUp"
QT_MOC_LITERAL(24, 395, 15), // "comMoveStepDown"
QT_MOC_LITERAL(25, 411, 15), // "comMoveStepLeft"
QT_MOC_LITERAL(26, 427, 16), // "comMoveStepRight"
QT_MOC_LITERAL(27, 444, 11), // "comInitPara"
QT_MOC_LITERAL(28, 456, 19), // "capClickClearButton"
QT_MOC_LITERAL(29, 476, 18), // "capClickScanButton"
QT_MOC_LITERAL(30, 495, 15), // "capClickConnect"
QT_MOC_LITERAL(31, 511, 17), // "capDoubleClickWin"
QT_MOC_LITERAL(32, 529, 16), // "capHandleChanged"
QT_MOC_LITERAL(33, 546, 1), // "p"
QT_MOC_LITERAL(34, 548, 20), // "vodClickBrowseButton"
QT_MOC_LITERAL(35, 569, 18), // "vodClickPlayButton"
QT_MOC_LITERAL(36, 588, 19), // "vodClickPauseButton"
QT_MOC_LITERAL(37, 608, 18), // "camClickOpenButton"
QT_MOC_LITERAL(38, 627, 10), // "processImg"
QT_MOC_LITERAL(39, 638, 3), // "img"
QT_MOC_LITERAL(40, 642, 9), // "errLogWin"
QT_MOC_LITERAL(41, 652, 3), // "err"
QT_MOC_LITERAL(42, 656, 9), // "comLogAdd"
QT_MOC_LITERAL(43, 666, 3), // "txt"
QT_MOC_LITERAL(44, 670, 4), // "type"
QT_MOC_LITERAL(45, 675, 14), // "comDeviceDelay"
QT_MOC_LITERAL(46, 690, 5), // "delay"
QT_MOC_LITERAL(47, 696, 10), // "formClosed"
QT_MOC_LITERAL(48, 707, 13) // "formCleanning"

    },
    "qtCyberDip\0bbqDiscoveryReadyRead\0\0"
    "bbqClickConnect\0bbqSelectDevice\0"
    "QListWidgetItem*\0item\0bbqDoubleClickDevice\0"
    "bbqClickBootstrapUSB\0bbqClickConnectUSB\0"
    "bbqADBProcessFinishes\0bbqADBProcessReadyRead\0"
    "bbqADBErrorReadyRead\0bbqQualityChanged\0"
    "index\0bbqBitrateChanged\0value\0"
    "bbqClickShowDebugLog\0comClickConnectButton\0"
    "comClickSendButton\0comClickClearButton\0"
    "comClickHitButton\0comClickRetButton\0"
    "comMoveStepUp\0comMoveStepDown\0"
    "comMoveStepLeft\0comMoveStepRight\0"
    "comInitPara\0capClickClearButton\0"
    "capClickScanButton\0capClickConnect\0"
    "capDoubleClickWin\0capHandleChanged\0p\0"
    "vodClickBrowseButton\0vodClickPlayButton\0"
    "vodClickPauseButton\0camClickOpenButton\0"
    "processImg\0img\0errLogWin\0err\0comLogAdd\0"
    "txt\0type\0comDeviceDelay\0delay\0formClosed\0"
    "formCleanning"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_qtCyberDip[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      37,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  199,    2, 0x08 /* Private */,
       3,    0,  200,    2, 0x08 /* Private */,
       4,    1,  201,    2, 0x08 /* Private */,
       7,    1,  204,    2, 0x08 /* Private */,
       8,    0,  207,    2, 0x08 /* Private */,
       9,    0,  208,    2, 0x08 /* Private */,
      10,    0,  209,    2, 0x08 /* Private */,
      11,    0,  210,    2, 0x08 /* Private */,
      12,    0,  211,    2, 0x08 /* Private */,
      13,    1,  212,    2, 0x08 /* Private */,
      15,    1,  215,    2, 0x08 /* Private */,
      17,    0,  218,    2, 0x08 /* Private */,
      18,    0,  219,    2, 0x08 /* Private */,
      19,    0,  220,    2, 0x08 /* Private */,
      20,    0,  221,    2, 0x08 /* Private */,
      21,    0,  222,    2, 0x08 /* Private */,
      22,    0,  223,    2, 0x08 /* Private */,
      23,    0,  224,    2, 0x08 /* Private */,
      24,    0,  225,    2, 0x08 /* Private */,
      25,    0,  226,    2, 0x08 /* Private */,
      26,    0,  227,    2, 0x08 /* Private */,
      27,    0,  228,    2, 0x08 /* Private */,
      28,    0,  229,    2, 0x08 /* Private */,
      29,    0,  230,    2, 0x08 /* Private */,
      30,    0,  231,    2, 0x08 /* Private */,
      31,    1,  232,    2, 0x08 /* Private */,
      32,    1,  235,    2, 0x08 /* Private */,
      34,    0,  238,    2, 0x08 /* Private */,
      35,    0,  239,    2, 0x08 /* Private */,
      36,    0,  240,    2, 0x08 /* Private */,
      37,    0,  241,    2, 0x08 /* Private */,
      38,    1,  242,    2, 0x08 /* Private */,
      40,    1,  245,    2, 0x08 /* Private */,
      42,    2,  248,    2, 0x0a /* Public */,
      45,    1,  253,    2, 0x0a /* Public */,
      47,    0,  256,    2, 0x0a /* Public */,
      48,    0,  257,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void, QMetaType::Int,   33,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QImage,   39,
    QMetaType::Void, QMetaType::QString,   41,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   43,   44,
    QMetaType::Void, QMetaType::Float,   46,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void qtCyberDip::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<qtCyberDip *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->bbqDiscoveryReadyRead(); break;
        case 1: _t->bbqClickConnect(); break;
        case 2: _t->bbqSelectDevice((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 3: _t->bbqDoubleClickDevice((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 4: _t->bbqClickBootstrapUSB(); break;
        case 5: _t->bbqClickConnectUSB(); break;
        case 6: _t->bbqADBProcessFinishes(); break;
        case 7: _t->bbqADBProcessReadyRead(); break;
        case 8: _t->bbqADBErrorReadyRead(); break;
        case 9: _t->bbqQualityChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->bbqBitrateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->bbqClickShowDebugLog(); break;
        case 12: _t->comClickConnectButton(); break;
        case 13: _t->comClickSendButton(); break;
        case 14: _t->comClickClearButton(); break;
        case 15: _t->comClickHitButton(); break;
        case 16: _t->comClickRetButton(); break;
        case 17: _t->comMoveStepUp(); break;
        case 18: _t->comMoveStepDown(); break;
        case 19: _t->comMoveStepLeft(); break;
        case 20: _t->comMoveStepRight(); break;
        case 21: _t->comInitPara(); break;
        case 22: _t->capClickClearButton(); break;
        case 23: _t->capClickScanButton(); break;
        case 24: _t->capClickConnect(); break;
        case 25: _t->capDoubleClickWin((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 26: _t->capHandleChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 27: _t->vodClickBrowseButton(); break;
        case 28: _t->vodClickPlayButton(); break;
        case 29: _t->vodClickPauseButton(); break;
        case 30: _t->camClickOpenButton(); break;
        case 31: _t->processImg((*reinterpret_cast< QImage(*)>(_a[1]))); break;
        case 32: _t->errLogWin((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 33: _t->comLogAdd((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 34: _t->comDeviceDelay((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 35: _t->formClosed(); break;
        case 36: _t->formCleanning(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject qtCyberDip::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_qtCyberDip.data,
    qt_meta_data_qtCyberDip,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *qtCyberDip::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *qtCyberDip::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_qtCyberDip.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int qtCyberDip::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 37)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 37;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 37)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 37;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
